public class Mother {
    int x = 10; 
    
    void show() {
        System.out.println("This is the show() method of the Mother class. Value of x: " + x);
    }
}