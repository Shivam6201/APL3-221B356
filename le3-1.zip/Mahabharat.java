
abstract class Bharatvanshi {
    abstract void fight();
}
abstract class Pandav extends Bharatvanshi {
    void fight() { System.out.println("Fights bravely!"); }
    void obey() { System.out.println("Always obedient!"); }
    void kind() { System.out.println("Very kind!"); }
}
class Arjun extends Pandav { }
class Bheem extends Pandav {
    void kind() { System.out.println("Less kind but still a good person!"); }
}
abstract class Kaurav extends Bharatvanshi {
    void fight() { System.out.println("Fights fiercely!"); }
    void obey() { System.out.println("Disobedient!"); }
    void kind() { System.out.println("Cruel!"); }
}
class Duryodhan extends Kaurav { }
class Vikarn extends Kaurav {
    void obey() { System.out.println("Obedient!"); }
    void kind() { System.out.println("Kind and noble!"); }
}
public class Mahabharat {
    public static void main(String[] args) {
        Arjun arjun = new Arjun();
        Bheem bheem = new Bheem();
        Duryodhan duryodhan = new Duryodhan();
        Vikarn vikarn = new Vikarn();

        System.out.println("Arjun:");
        arjun.fight();
        arjun.obey();
        arjun.kind();

        System.out.println("\nBheem:");
        bheem.fight();
        bheem.obey();
        bheem.kind();

        System.out.println("\nDuryodhan:");
        duryodhan.fight();
        duryodhan.obey();
        duryodhan.kind();

        System.out.println("\nVikarn:");
        vikarn.fight();
        vikarn.obey();
        vikarn.kind();
    }
}
