class Bear extend Beverage{
    protected void add condiment(){
        system.out.println("nothing");
    }
}