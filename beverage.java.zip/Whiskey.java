class Whiskey extends Beverage{
    protected void addcondiment(){
        system.out.println("add some ice");
    }
    protected void stir(){
        system.out.println("stir for 30 sec");
    }
}