abstract class Beverage{
    private void pour(int qty){
        system.out.println("pour"+qty+"ml of beverage in a glass");
    }
    protected abstract void addcondiment();
    
    protected void stir(){
        
    }
    private void serve(){
        system.out.println("serve through waiter");
    }
    public void templatemethod(int qty){
        pour(qty);
        add condiment();
        stir();
        serve();
        
    }
}